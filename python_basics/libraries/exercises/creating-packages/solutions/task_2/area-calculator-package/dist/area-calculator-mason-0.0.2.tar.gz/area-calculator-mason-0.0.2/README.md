# Area Calculator

This is an example package.

It calculates the rea of different geometrical shapes and returns the results.
It is great for use with math homework problems.
