from .area_calculator_dci import (welcome, square, rectangle,
                                  triangle, circle)
