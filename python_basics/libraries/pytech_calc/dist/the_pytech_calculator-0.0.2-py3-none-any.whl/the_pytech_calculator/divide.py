"""Simple module for dividing 2 numbers."""


def divide(x, y):
    """Divides x into y and returns the quotient."""
    return x // y
