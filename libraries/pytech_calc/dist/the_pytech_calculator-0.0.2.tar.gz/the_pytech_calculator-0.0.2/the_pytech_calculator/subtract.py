"""Simple module to subtract one number for the other."""


def subtract(x, y):
    """Subtracts y from x and returns the difference."""
    return x - y
