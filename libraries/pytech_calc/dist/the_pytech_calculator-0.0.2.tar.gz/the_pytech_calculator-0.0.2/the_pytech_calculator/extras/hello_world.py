"""Simple module to print a string."""


def hello(name):
    """Prints hello + name of user."""
    return f"Hello, {name}!"
