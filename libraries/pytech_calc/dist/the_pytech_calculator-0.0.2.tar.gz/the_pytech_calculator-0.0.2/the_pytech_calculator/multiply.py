"""simple module for multiplying 2 numbers."""


def multiply(x, y):
    """Multiply x and y and return the product."""
    return x * y
