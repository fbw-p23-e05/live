"""Simple module to add 2 numbers."""


def add(x, y):
    """Adds x and y and returns the sum"""
    return x + y
